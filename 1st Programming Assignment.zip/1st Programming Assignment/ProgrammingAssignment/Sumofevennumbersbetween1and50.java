package ProgrammingAssignment;

import java.util.Scanner;

public class Sumofevennumbersbetween1and50 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

        // Input four numbers
        System.out.print("Enter first number: ");
        int num1 = sc.nextInt();

        System.out.print("Enter second number: ");
        int num2 = sc.nextInt();

        System.out.print("Enter third number: ");
        int num3 = sc.nextInt();

        System.out.print("Enter fourth number: ");
        int num4 = sc.nextInt();

        // Find the largest number
        int largest = num1;

        if (num2 > largest) {
            largest = num2;
        }

        if (num3 > largest) {
            largest = num3;
        }

        if (num4 > largest) {
            largest = num4;
        }

        System.out.println("The largest number is: " + largest);

        sc.close();
		
		
	}

}
