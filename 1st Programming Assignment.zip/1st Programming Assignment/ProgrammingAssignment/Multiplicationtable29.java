package ProgrammingAssignment;

public class Multiplicationtable29 {

	public static void main(String[] args) {

		int num = 29;
        int i = 1;

        System.out.println("Multiplication Table of 29:");

        while (i <= 10) {
            int product = num * i;
            System.out.println(num + " x " + i + " = " + product);
            i++;
		
		
	}

}
}
