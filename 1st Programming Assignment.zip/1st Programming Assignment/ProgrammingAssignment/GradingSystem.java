package ProgrammingAssignment;

import java.util.Scanner;

public class GradingSystem {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

        // Input total marks
        System.out.print("Enter total marks (0-100): ");
        int totalMarks = sc.nextInt();

        // Input maths marks
        System.out.print("Enter marks in Maths: ");
        int mathsMarks = sc.nextInt();

        // Grading logic
        if (totalMarks < 20) {
            System.out.println("Result: Fail");
        } else if (totalMarks >= 20 && totalMarks < 40 && mathsMarks < 20) {
            System.out.println("Grade: D");
        } else if (totalMarks >= 40 && totalMarks < 60 && mathsMarks > 30) {
            System.out.println("Grade: C");
        } else if (totalMarks >= 60 && totalMarks < 80 && mathsMarks > 60) {
            System.out.println("Grade: B");
        } else if (totalMarks >= 80 && totalMarks <= 100 && mathsMarks > 80) {
            System.out.println("Grade: A");
        } else {
            System.out.println("No grade assigned based on the conditions.");
        }

        sc.close();
    }




		
		
	}


