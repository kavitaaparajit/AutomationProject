package ProgrammingAssignment;

public class First10oddnumbers {

	public static void main(String[] args) {

		System.out.println("The first 10 odd numbers are:");
        int count = 0;
        int num = 1;

        while (count < 10) {
            System.out.print(num + " ");
            num += 2;
            count++;
		
        }
	}
}


