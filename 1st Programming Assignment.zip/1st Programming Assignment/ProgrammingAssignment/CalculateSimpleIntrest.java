package ProgrammingAssignment;

import java.util.Scanner;

public class CalculateSimpleIntrest {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

        // Input principal amount
        System.out.print("Enter principal amount (P): ");
        double principal = sc.nextDouble();

        // Input rate of interest
        System.out.print("Enter rate of interest (R): ");
        double rate = sc.nextDouble();

        // Input time in years
        System.out.print("Enter time in years (T): ");
        double time = sc.nextDouble();

        // Calculate Simple Interest
        double simpleInterest = (principal * rate * time) / 100;

        // Display result
        System.out.println("Simple Interest: " + simpleInterest);

        sc.close();
		
		
		
		
		
	}

}
