package ProgrammingAssignment;

public class largestbetween4numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
